#! /bin/sh
gdb bootimg < gdb_command.txt

