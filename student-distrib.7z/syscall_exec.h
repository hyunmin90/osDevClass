#ifndef _SYSCALL_EXEC_H
#define _SYSCALL_EXEC_H

int32_t do_execute(const int8_t* command);

#endif
