#! /bin/sh

make clean
make dep
make

